﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO; //Add this for input/output

namespace FileStuff
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
              FileStream - creates or reads from a file
              path - the place where you read/write files
           
              FileMode:
              Append - adds text to the end of the file
              Create - creates a file
              CreateNew - create a file, but if it exists, DIE
              Open - opens a file
              OpenOrCreate - either open a file, or make it
              Truncate - opens a file and deletes all its stuff

              FileAccess:
              Read - get data from the file
              Write - put data in the file
              ReadWrite - get or put data (why not both?)
            */

            string path = "C:\\206stuff\\users.txt";//MAKE DIRECTORY 206stuff!


            //1         // Code to write to a file  
            //FileStream fs = new FileStream(
            //    path,
            //    FileMode.Append, //OPENORCREATE FIRST
            //    FileAccess.Write);
            //StreamWriter fileOut = new StreamWriter(fs);

            //List<string> names = new List<string>();
            //names.Add("James");
            //names.Add("Sam");
            //names.Add("Sarah");

            //foreach (string name in names)
            //{
            //    fileOut.WriteLine(name);
            //}
            //fileOut.Close();



            //2         //Code to read a file
            //FileStream fs = new FileStream(
            //    path,
            //    FileMode.Open,
            //    FileAccess.Read);
            //StreamReader fileIn = new StreamReader(fs);
            //while (fileIn.Peek() != -1)
            //{
            //    Console.WriteLine(fileIn.ReadLine());
            //}
            //fileIn.Close();
            //Console.ReadKey();



            //3         //Code To Write multiple entries into one line
            //FileStream fs = new FileStream(
            //    path,
            //    FileMode.OpenOrCreate,
            //    FileAccess.Write);
            //StreamWriter fileOut = new StreamWriter(fs);
            ////You can use a delimiter to seperate your data on one line
            //fileOut.WriteLine("ApplePie|MehApples|apples@apples.com");
            //fileOut.WriteLine("MyUsername|MyPassword|MyEmailAddress@email.com");
            //fileOut.Close();



            //4 Code to read a file and parse the data
            //FileStream fs = new FileStream(
            //    path,
            //    FileMode.Open,
            //    FileAccess.Read);
            //StreamReader fileIn = new StreamReader(fs);
            //while (fileIn.Peek() != -1)
            //{
            //    string theLine = fileIn.ReadLine();
            //    string[] columns = theLine.Split('|');
            //    string username = columns[0];
            //    string password = columns[1];
            //    string email = columns[2];

            //    Console.WriteLine("Username: " + username);
            //    Console.WriteLine("Password: " + password);
            //    Console.WriteLine("Email: " + email);
            //    Console.WriteLine();
            //}
            //fileIn.Close();
            //Console.ReadKey();
            
        }
    }
}
